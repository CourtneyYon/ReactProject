# individual-project-CourtneyYon
individual-project-CourtneyYon created by GitHub Classroom

# Please see rule book inside opoly folder

# Deployment URL
Here:  https://front-end-opoly.now.sh/ 

# About 
* The project was given to us for Socio Informatics/Information Systems Management 354 Capstone Module at the University of Stellenbosch. Where students could choose options either via a Social network or Game Development appplication. It aimed to allow for the student to learn more about react.js, HTML, CSS and JavaScript and how they "fit".


# Things learnt
* Coding is a different dimension and when learning to "build" it gave me a kick. Therefore, learnt and read up on different front end
 frameworks.
* This project has taught me that there are many ways and possible soulutions to problems and so it is okay to struggle at first. However,  the more you build and "beat" at your skills. You can learn from others and you are not in it alone.
* React.js is a wonderful tool for game development especially when you grasp it.
* Front end developing enables you to grasp design issues at a different level.

# Acknowledgements
* Mr Richard Barnett
* The coding Garden

# Future 
* Due to the interest sparked regarding game development and love for this "type" of coding. I will work on it after hours to allow for more growth and learning curves.
* This was work that was referenced from the coding garden and I aim to create code from scratch
