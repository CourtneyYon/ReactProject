# Rule Book

* This is a 2 player game which allows players to select their "characters" in this it is chess pawns. These include:
  1. Yellow (JavaScript)
  2. Red (Angular)
  3. Blue (React)
  4. Green (Vue)
* The board generates based on player choices:
  * 1 "Rest from JavaScript Fatigue" square is the start
  * Squares with player 1 logo
  * Squares with player 2 logo
  * Face off squares
* Game play:
  * Player rolls dice
  * Player moves forward one square up to the number rolled 
  * If the player lands on their own color square: +1 Point
  * If the player lands on the oponent color square:
    * -1 Point to the Player
    * +1 Point to the Oponent
  * If the player lands on a face off square:
    * Both players roll the dice once
    * The higher roll wins the difference of the 2 rolls as points
  * If the player lands on the "Rest from JavaScript Fatigue", the player rests
* First player to 20 points wins
  
